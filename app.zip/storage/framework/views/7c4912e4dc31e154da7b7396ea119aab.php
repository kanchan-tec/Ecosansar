<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.shared/page-title',['page_title' => 'Google Maps','sub_title' => 'Maps'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h4 class="header-title mb-0">Basic Google Map</h4>
            </div>
            <div class="card-body">
                <div id="gmaps-basic" class="gmaps"></div>
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h4 class="header-title mb-0">Markers Google Map</h4>
            </div>
            <div class="card-body">
                <div id="gmaps-markers" class="gmaps"></div>
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->
</div>
<!-- end row-->

<div class="row">
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h4 class="header-title mb-0">Street View Panoramas Google Map</h4>
            </div>
            <div class="card-body">
                <div id="panorama" class="gmaps"></div>
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h4 class="header-title mb-0">Google Map Types</h4>
            </div>
            <div class="card-body">
                <div id="gmaps-types" class="gmaps"></div>
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->
</div>
<!-- end row-->

<div class="row">
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h4 class="header-title mb-0">Ultra Light with Labels</h4>
            </div>
            <div class="card-body">
                <div id="ultra-light" class="gmaps"></div>
            </div>
            <!-- end card-body-->
        </div>
        <!-- end card-->
    </div>
    <!-- end col-->
    <div class="col-xl-6">
        <div class="card">
            <div class="card-header">
                <h4 class="header-title mb-0">Dark</h4>
            </div>
            <div class="card-body">
                <div id="dark" class="gmaps"></div>
            </div>
            <!-- end card-body-->
        </div>
        <!-- end card-->
    </div>
    <!-- end col-->
</div>
<!-- end row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Google Maps API -->
    <script src="https://maps.google.com/maps/api/js"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/google-maps.init.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'Google Maps', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ct9/Desktop/Ishan/velonic/velonic_laravel/velonic/resources/views/maps/google.blade.php ENDPATH**/ ?>