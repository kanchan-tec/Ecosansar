

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.shared/page-title', ['sub_title' => 'Icons', 'page_title' => 'Bootstrap Icons'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Icons</h5>
                    <p class="text-muted">Use class
                        <code>&lt;i class=&quot;bi bi-123&quot;&gt;&lt;/i&gt;</code>
                    </p>
                    <div class="row icons-list-demo" id="bootstrap-icons"></div>
                </div> <!-- end card body -->
            </div> <!-- end card -->
        </div> <!-- end col -->
    </div> <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- MDI Icons Demo js -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/icons-bootstrap.init.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'Bootstrap Icons', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ct9/Desktop/Ishan/velonic/velonic_laravel/velonic/resources/views/icons/bootstrap.blade.php ENDPATH**/ ?>