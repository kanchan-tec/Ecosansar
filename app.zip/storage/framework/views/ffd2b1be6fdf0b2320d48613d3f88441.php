<!-- start page title -->
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Ecosansar</a></li>
                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($sub_title); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e($page_title); ?></li>
                </ol>
            </div>
            <h4 class="page-title"><?php echo e($page_title); ?></h4>
        </div>
    </div>
</div>
<!-- end page title -->
<?php /**PATH C:\xampp\htdocs\ecosansar\resources\views/layouts/shared/page-title.blade.php ENDPATH**/ ?>