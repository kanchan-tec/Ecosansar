<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 text-center">
                <script>document.write(new Date().getFullYear())</script> © Velonic - Theme by <b>Techzaa</b>
            </div>
        </div>
    </div>
</footer>
<!-- end Footer --><?php /**PATH /home/ct9/Desktop/Ishan/velonic/velonic_laravel/velonic/resources/views/layouts/shared/footer.blade.php ENDPATH**/ ?>