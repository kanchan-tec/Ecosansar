<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['node_modules/select2/dist/css/select2.min.css', 'node_modules/daterangepicker/daterangepicker.css', 'node_modules/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.css', 'node_modules/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css', 'node_modules/bootstrap-timepicker/css/bootstrap-timepicker.min.css', 'node_modules/flatpickr/dist/flatpickr.min.css']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.shared/page-title', ['sub_title' => 'Add', 'page_title' => 'FAQ Add'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="row">
    <div class="col-12">
        <div class="card">

            <div class="card-body">
                <form action="<?php echo e(route('Faq.save')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-6">
                        <!-- Date Range -->
                        <div class="mb-3">
                            <label for="simpleinput" class="form-label">Question</label>
                            <input type="text" id="question" name="question" class="form-control">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <!-- Date Range Picker With Times -->
                        <div class="mb-3">
                            <label for="simpleinput" class="form-label">Answer</label>
                            <input type="text" id="answer" name="answer" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="mb-3">
                            <button class="btn btn-primary" type="submit">Submit form</button>
                        </div>
                    </div>
                </div>
            </form>


            </div> <!-- end card-body -->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/form-advanced.init.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'FAQ Add', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecosansar\resources\views/admin/faq/add.blade.php ENDPATH**/ ?>