<!-- bundle -->
<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->
<?php echo $__env->yieldContent('script-bottom'); ?><?php /**PATH C:\xampp\htdocs\ecosansar\resources\views/layouts/shared/footer-scripts.blade.php ENDPATH**/ ?>