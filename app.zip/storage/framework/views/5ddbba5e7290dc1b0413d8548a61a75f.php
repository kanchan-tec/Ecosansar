<?php echo app('Illuminate\Foundation\Vite')([
    'resources/js/head.js',
    'resources/js/config.js',
    'resources/scss/app.scss',
    'resources/scss/icons.scss'
    ]); ?>
<?php /**PATH C:\xampp\htdocs\ecosansar\resources\views/layouts/shared/head-css.blade.php ENDPATH**/ ?>