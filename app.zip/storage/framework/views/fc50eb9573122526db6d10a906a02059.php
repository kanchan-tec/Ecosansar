<?php echo app('Illuminate\Foundation\Vite')([
    'resources/js/head.js',
    'resources/js/config.js',
    'resources/scss/app.scss',
    'resources/scss/icons.scss'
    ]); ?>
<?php /**PATH /home/ct9/Desktop/Ishan/velonic/velonic_laravel/velonic/resources/views/layouts/shared/head-css.blade.php ENDPATH**/ ?>